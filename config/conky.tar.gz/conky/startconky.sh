#!/bin/bash 
conky --config=/home/mississippi/bin/conky/.conky.conf
